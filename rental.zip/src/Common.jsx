import React from 'react'

const Common = () => {
  return (
    <div>
      
    </div>
  )
}

export default Common
