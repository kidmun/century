
export const links = [
    {
        name: "Home",
        path: "/"
    },
    {
        name: "Shops",
        path: "/shops"
    },
    {
        name: "Movies",
        path: "/movies"
    },
    // {
    //     name: "About",
    //     path: "/about"
    // },
    // {
    //     name: "Contact",
    //     path:"/contact"
    // }
]