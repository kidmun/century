import React from 'react'
import { useState } from 'react'
import AdminNavbar from './AdminNavbar'


const AddFeature = () => {
  const [title, setTitle] = useState(null);
  const [titleError, setTitleError] = useState(false);
  const [image, setImage] = useState(null);
  const [imageError, setImageError] = useState(false);
  const [description, setDescription] = useState(null);
  const [descriptionError, setDescriptionError] = useState(false);
  const titleChangeHandler = (event) => {
    setTitle(event.target.value);
    if (!event.target.value){
      setTitleError(true);
    }
    else{
      setTitleError(false);
    }
  };
  const imageChangeHandler = (event) => {
    setImage(event.target.files[0]);
    if (!event.target.files){
      setImageError(true);
    }
    else{
      setImageError(false);
    }
  };
  const descriptionChangeHandler = (event) => {
    setDescription(event.target.value);
    if (event.target.value.length < 5){
      setDescriptionError(true);
    }
    else{
      setDescriptionError(false);
    }
  };

  const submitHandler = (event) => {
    event.preventDefault();
    
    if (title && image && description && description.length > 5){
      console.log("ddd")
      const formData = new FormData();
      formData.append("title", title);
      formData.append("image", image);
      formData.append("description", description);
      fetch("http://localhost:8080/feature", {
        method: "POST", 
        body: formData
      }).then(response => {
        if(!response.ok){
          throw new Error("response not ok");
        }
        return response.json();
      }).then(result => {
        console.log(result)
      }).catch(err => {
        console.log(err)
      });
      
      
    };
  };

  return (<>
  <AdminNavbar/>
  
    <div className="Contact__header">
          <div className="Contact__header-container">
            <div className="Contact__header-container-header">
                <h2>Add Feature</h2>
               
            </div>
            <div className="Contact__header-container-form">
                <form className="Contact__header-form" onSubmit={submitHandler}>
                    <label htmlFor='title'>Title</label>
                    <input type="text" name="title" id="title" placeholder="Enter title" onChange={titleChangeHandler} value={title}></input>
                    {titleError && <p style={{color: "red"}}>enter a title</p>}
                    <label htmlFor='image'>Image</label>
                    <input type="file" name="image" id="image" onChange={imageChangeHandler}></input>
                    
                    <label htmlFor='description'>Description</label>
                    <input type="description" name="description" id="description" placeholder="description" onChange={descriptionChangeHandler}></input>   
                    {descriptionError && <p style={{color: "red"}}>enter description</p>}
                    <button type='submit'>Submit</button>
                </form>
                
            </div>
          </div>
          <div className="Contact__header-container-Contacts">
        
          
          </div>
    </div>
    </>
  )
}

export default AddFeature
