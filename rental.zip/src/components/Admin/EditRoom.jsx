import React from 'react'
import { useEffect } from 'react';
import { useState } from 'react'
import { useNavigate, useParams } from "react-router-dom";
import AdminNavbar from './AdminNavbar'


const EditRoom = () => {
    const navigate = useNavigate();
  const {id } = useParams();
 
  const [title, setTitle] = useState(null);

  const [image, setImage] = useState(null);
  const [imageError, setImageError] = useState(false);
  const [floorNo, setFloorNo] = useState(null);
  const [floorNoError, setFloorNoError] = useState(false);
  const [roomNo, setRoomNo] = useState(null);
  const [roomNoError, setRoomNoError] = useState(false);
  const [available, setAvailable] = useState(false);
  useEffect(() => {
    fetch("http://localhost:8080/rooms/"+id).then(response => {
      if (!response.ok){
        console.log(response)
        throw new Error("response not ok");
      }
      return response.json();
    }).then(result => {
   
      setTitle(result.room.title);
      setFloorNo(result.room.floorNo);
      setRoomNo(result.room.roomNo);
      setImage(result.room.imageUrl);
      if (result.room.available){
            setAvailable(true)
      }
      else{
      setAvailable(false);
    }
     
    })
    .catch(err => {
      console.log(err)
    });
  }, []);

  const titleChangeHandler = (event) => {
    setTitle(event.target.value);
  };
  const imageChangeHandler = (event) => {
    setImage(event.target.files[0]);
    if (!event.target.files){
      setImageError(true);
    }
    else{
      setImageError(false);
    }
  };
  const floorNoChangeHandler = (event) => {
    setFloorNo(event.target.value);
    if (event.target.value.length < 2){
      setFloorNoError(true);
    }
    else{
      setFloorNoError(false);
    }
  };
  const roomChangeHandler = (event) => {
    setRoomNo(event.target.value);
  
    if (event.target.value.length < 3){
      setRoomNoError(true);
    }
    else{
      setRoomNoError(false);
    }
  };
  const availableChangeHandler = (event) => {
    console.log(event.target.checked)
    setAvailable(event.target.checked);
  }
  const submitHandler = (event) => {
    event.preventDefault();

    if (image && floorNo && floorNo.length > 1 && roomNo && roomNo.length > 2){
        console.log(available)
      const formData = new FormData();
      formData.append("title", title);
      formData.append("image", image);
      formData.append("floorNo", floorNo);
      formData.append("roomNo", roomNo);
      formData.append("available", available);
      fetch("http://localhost:8080/room/"+id, {
        method: "PUT", 
        body: formData
      }).then(response => {
        if(!response.ok){
          throw new Error("response not ok");
        }
        return response.json();
      }).then(result => {
        console.log(result)
        navigate("/admin/rooms");
      }).catch(err => {
        console.log(err)
      });
      
      
    };
  };

  return (<>
  <AdminNavbar/>
  
    <div className="Contact__header">
          <div className="Contact__header-container">
            <div className="Contact__header-container-header">
                <h2>Edit Room</h2>
            </div>
            <div className="Contact__header-container-form">
                <form className="Contact__header-form" onSubmit={submitHandler}>
                    <label htmlFor='title'>Title(optional)</label>
                    <input type="text" name="title" id="title" placeholder="Enter title" onChange={titleChangeHandler} value={title}></input>
                   
                    <label htmlFor='image'>Image</label>
                    <input type="file" name="image" id="image" onChange={imageChangeHandler}></input>
                    
                    <label htmlFor='floorNo'>Floor NO</label>
                    <input type="text" name="floorNo" id="floorNo" placeholder="floorNo" onChange={floorNoChangeHandler} value={floorNo}></input>   
                    {floorNoError && <p style={{color: "red"}}>enter floor</p>}
                    <label htmlFor='roomNo'>Room NO</label>
                    <input type="text" name="roomNo" id="roomNo" placeholder="roomNo" onChange={roomChangeHandler} value={roomNo}></input>   
                    {roomNoError && <p style={{color: "red"}}>enter room</p>}
                    <br/>
                <div>  
                    <input type="checkbox" checked={available} id="male"
              onChange={availableChangeHandler} name="available" />
               <label htmlFor="male">Available</label>
                    
               </div>
                    <button type='submit'>Submit</button>
                </form>
                
            </div>
          </div>
          <div className="Contact__header-container-Contacts">
        
          
          </div>
    </div>
    </>
  )
}

export default EditRoom
