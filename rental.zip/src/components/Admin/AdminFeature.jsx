import React, { useState, useEffect } from 'react'

import Kids from "../../assets/Kids.png"
import Cinema from "../../assets/Cinema.png"
import PopCorn from "../../assets/Pop Corn.png"
import { useNavigate } from 'react-router-dom'

const AdminFeature = () => {
  const navigate = useNavigate();
    const [features, setFeatures] = useState([]);
    const [deleteMode, setDeleteMode] = useState(false);
    useEffect(() => {
        fetch("http://localhost:8080/features").then((response) => {
          if (!response.ok){
            throw new Error("response not ok");
          }
          return response.json();
        }).then(result => {
          console.log(result);
          setFeatures(result.features);
        }).catch(err => {
          console.log(err);
        });
      }, []);
      const editHandler = (id) => {
        console.log(id)
navigate("/admin/edit_feature/"+id);
      }
      


  return (
    <div className="Movies__feature">

        <div className="Movies__feature-container">
            <div className="Movies__feature-container-features">
            <button style={{width: "150px", height: "45px", backgroundColor:"#041d51", color: "white"}} onClick={() => {
                  navigate("/admin/add_feature");
            }}>Add Feature</button>
                {features && features.map(feature => <div className="Movies__feature-container-kids">
                    <img src={"http://localhost:8080/images/" +
                feature.imageUrl.slice(7, feature.imageUrl.length)} alt="Kids"/>
                    <div className="Movies__feature-container-text">
                    <h1>{feature.title}</h1>
                    <p>{feature.description}</p>
                   {!deleteMode && <button style={{width: "100px", height: "45px", backgroundColor:"#041d51", color: "white"}} onClick={editHandler.bind(this, feature._id)}>Edit</button>} 
              
                    {!deleteMode && <button style={{width: "100px", height: "45px",  color: "white", backgroundColor:"#8a0404"}} onClick={() => {
                      setDeleteMode(true);
                      navigate("/delete/"+feature._id);
                    }}>Delete</button>}
                    
                    </div>
                </div>)}
               
            </div>
        </div>
    </div>
  )
}

export default AdminFeature
