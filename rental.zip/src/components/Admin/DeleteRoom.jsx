import React from "react"
import { useNavigate, useParams } from "react-router-dom"
import  Backdrop from "../Backdrop/Backdrop"
import Modal from "../Modal/Modal"
const DeleteRoom = () => {
  const {id} = useParams();
  const navigate = useNavigate();
  const cancelDeleteHandler = () => {
navigate(-1);
  }
  const acceptDeleteHandler = () => {
    fetch("http://localhost:8080/room/" + id, {
      method: "DELETE"
    }).then(response => {
      if (!response){
        throw new Error("response not ok");
      }
      return response.json()
    })
    .then(result => {
  
      navigate(-1)
    }).catch(err => {
      console.log(err)
    });
  }
    return  <>
    <Backdrop onClick={cancelDeleteHandler} />
    <Modal
      title="Delete Room"
      acceptEnabled={true}
      onCancelModal={cancelDeleteHandler}
      onAcceptModal={acceptDeleteHandler}
      isLoading={false}
    >
      <h1>Are you sure you want to delete this?</h1>
    </Modal>
  </>
  }

  export default DeleteRoom