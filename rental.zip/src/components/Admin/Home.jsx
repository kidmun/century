import React from "react";
import AdminNavbar from "./AdminNavbar";
import AdminFeature from "./AdminFeature";

const AdminHome = () => {

    return <>
        <AdminNavbar/>
        <AdminFeature/>
       
    </>
};

export default AdminHome;