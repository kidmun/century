import React from 'react'
import {Link} from  "react-router-dom"
import Deal from "../../assets/Deal.jpg"

const ShopDeal = () => {
  return (
    <div className="Deal__container">
    <div className="Deal__container-header01">
      <div className="Deal__container-header">
      <img src={Deal} alt="Deal"/>
      <div className="Deal__container-header-heading">
        <h1>Fana kids</h1>
        <p>Not-available</p>
      </div>
      <div className="Deal__container-header-subheading">
        <h3>Ground Floor</h3>
        <h4>No.01</h4>
      </div>
      <Link to= "/About" className="Deal__header-content-button">More Info</Link>
      </div>

      <div className="Deal__container-header">
      <img src={Deal} alt="Deal"/>
      <div className="Deal__container-header-heading">
        <h1>Fana kids</h1>
        <p>Not-available</p>
      </div>
      <div className="Deal__container-header-subheading">
        <h3>Ground Floor</h3>
        <h4>No.01</h4>
      </div>
      <Link to= "/About" className="Deal__header-content-button">More Info</Link>
      </div>

      <div className="Deal__container-header">
      <img src={Deal} alt="Deal"/>
      <div className="Deal__container-header-heading">
        <h1>Fana kids</h1>
        <p>Not-available</p>
      </div>
      <div className="Deal__container-header-subheading">
        <h3>Ground Floor</h3>
        <h4>No.01</h4>
      </div>
      <Link to= "/About" className="Deal__header-content-button">More Info</Link>
      </div>

    </div>


    <div className="Deal__container-header01">
      <div className="Deal__container-header">
      <img src={Deal} alt="Deal"/>
      <div className="Deal__container-header-heading">
        <h1>Fana kids</h1>
        <p>Not-available</p>
      </div>
      <div className="Deal__container-header-subheading">
        <h3>Ground Floor</h3>
        <h4>No.01</h4>
      </div>
      <Link to= "/About" className="Deal__header-content-button">More Info</Link>
      </div>

      <div className="Deal__container-header">
      <img src={Deal} alt="Deal"/>
      <div className="Deal__container-header-heading">
        <h1>Fana kids</h1>
        <p>Not-available</p>
      </div>
      <div className="Deal__container-header-subheading">
        <h3>Ground Floor</h3>
        <h4>No.01</h4>
      </div>
      <Link to= "/About" className="Deal__header-content-button">More Info</Link>
      </div>

      <div className="Deal__container-header">
      <img src={Deal} alt="Deal"/>
      <div className="Deal__container-header-heading">
        <h1>Fana kids</h1>
        <p>Not-available</p>
      </div>
      <div className="Deal__container-header-subheading">
        <h3>Ground Floor</h3>
        <h4>No.01</h4>
      </div>
      <Link to= "/About" className="Deal__header-content-button">More Info</Link>
      </div>

    </div>

    <div className="Deal__container-header01">
      <div className="Deal__container-header">
      <img src={Deal} alt="Deal"/>
      <div className="Deal__container-header-heading">
        <h1>Fana kids</h1>
        <p>Not-available</p>
      </div>
      <div className="Deal__container-header-subheading">
        <h3>Ground Floor</h3>
        <h4>No.01</h4>
      </div>
      <Link to= "/About" className="Deal__header-content-button">More Info</Link>
      </div>

      <div className="Deal__container-header">
      <img src={Deal} alt="Deal"/>
      <div className="Deal__container-header-heading">
        <h1>Fana kids</h1>
        <p>Not-available</p>
      </div>
      <div className="Deal__container-header-subheading">
        <h3>Ground Floor</h3>
        <h4>No.01</h4>
      </div>
      <Link to= "/About" className="Deal__header-content-button">More Info</Link>
      </div>

      <div className="Deal__container-header">
      <img src={Deal} alt="Deal"/>
      <div className="Deal__container-header-heading">
        <h1>Fana kids</h1>
        <p>Not-available</p>
      </div>
      <div className="Deal__container-header-subheading">
        <h3>Ground Floor</h3>
        <h4>No.01</h4>
      </div>
      <Link to= "/About" className="Deal__header-content-button">More Info</Link>
      </div>

    </div>


  </div>
  )
}

export default ShopDeal