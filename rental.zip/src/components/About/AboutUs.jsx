import React from 'react'

const AboutUs = () => {
  return (
    <div className="About__container">
      <div className="About__container-content">
         <div className="About__container-Header">
              <h1>Who are we?</h1>
              <p>Got a question? We're here to answer! If you don't see your question here , 
                drop us a line at the contact us page. Got a question?We're here to answer! 
                If you don't see your question   here , drop us a line at the contact us page.</p>
        </div>
        <div className="About__container-header_faqs">
        <h1> Frequently Asked Questions(FAQs)</h1>
        <p>Got a question? We're here to answer! If you don't see your question 
                    here , drop us a line at the contact us page.</p>

        </div>
        <div className="About_faqs">
            <div className="About__container-faqs">
              <div className="About__container-title">
                  <h1>Where is century mall located?</h1>
                  <p>Got a question? We're here to answer! If you don't see your question
                     here , drop us a line at the contact us page.</p>
              </div>

              
              <div className="About__container-title">
                  <h1>Where is century mall located?</h1>
                  <p>Got a question? We're here to answer! If you don't see your question
                     here , drop us a line at the contact us page.</p>
              </div>
            </div>






            <div className="About__container-faqs">
              <div className="About__container-title">
                  <h1>Where is century mall located?</h1>
                  <p>Got a question? We're here to answer! If you don't see your question
                     here , drop us a line at the contact us page.</p>
              </div>

              
              <div className="About__container-title">
                  <h1>Where is century mall located?</h1>
                  <p>Got a question? We're here to answer! If you don't see your question
                     here , drop us a line at the contact us page.</p>
              </div>
            </div>





            <div className="About__container-faqs">
              <div className="About__container-title">
                  <h1>Where is century mall located?</h1>
                  <p>Got a question? We're here to answer! If you don't see your question
                     here , drop us a line at the contact us page.</p>
              </div>

              
              <div className="About__container-title">
                  <h1>Where is century mall located?</h1>
                  <p>Got a question? We're here to answer! If you don't see your question
                     here , drop us a line at the contact us page.</p>
              </div>
            </div>






            <div className="About__container-faqs">
              <div className="About__container-title">
                  <h1>Where is century mall located?</h1>
                  <p>Got a question? We're here to answer! If you don't see your question
                     here , drop us a line at the contact us page.</p>
              </div>

              
              <div className="About__container-title">
                  <h1>Where is century mall located?</h1>
                  <p>Got a question? We're here to answer! If you don't see your question
                     here , drop us a line at the contact us page.</p>
              </div>
            </div>



            <div className="About__container-faqs">
              <div className="About__container-title">
                  <h1>Where is century mall located?</h1>
                  <p>Got a question? We're here to answer! If you don't see your question
                     here , drop us a line at the contact us page.</p>
              </div>

              
              <div className="About__container-title">
                  <h1>Where is century mall located?</h1>
                  <p>Got a question? We're here to answer! If you don't see your question
                     here , drop us a line at the contact us page.</p>
              </div>
            </div>

            
        </div>
      </div>
    </div>
  )
}

export default AboutUs